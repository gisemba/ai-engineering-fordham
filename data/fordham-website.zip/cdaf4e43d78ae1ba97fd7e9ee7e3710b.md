https://www.fordham.edu/give/the-campaign-for-financial-aid/invest-in-our-mission/brittany-ballentine

# Brittany Ballentine

![Brittany Ballentine](/media/review/content-assets/migrated/images/FH_Brittany_Ballentine.jpg)


### Dancing Around the World

Though she’d been dancing since age 4, when Brittany Ballentine, FCLC ’15, was in high school, she wasn’t sure she wanted to pursue dance professionally. But she had a dance teacher who encouraged her. “He told me, ‘Brittany, you have a gift.’” She was thrilled when she got into the Ailey/Fordham BFA in Dance program. “That’s where he really wanted me to go,” she says.

During her sophomore year, Ballentine received Fordham’s Robert E. Campbell Scholarship at just the right time. “I was trying to figure out how to continue paying tuition as well as room and board. I knew I needed to live in Manhattan—in the heart of the city,” says the Baltimore native. She earned the Denise Jefferson Memorial Scholarship as a junior, based on artistic merit. While at Fordham, Ballentine performed with Ailey dancers at prestigious New York venues, including the Apollo Theater and City Center. “I felt like I was living my dream,” she says. Ballentine danced with the Evidence dance company before joining Norwegian Cruise Line, where she performs in on-ship Broadway-style shows. “I wanted to travel more and see more,” she says. The gig has brought her to Europe, South America, and the Caribbean.

She remains grateful to Fordham for getting her career underway. “Fordham enabled me to build relationships with the very people who inspire me,” she says.