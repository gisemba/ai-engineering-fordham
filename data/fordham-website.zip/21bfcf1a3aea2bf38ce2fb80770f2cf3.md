https://www.fordham.edu/give/celebrating-donors/advisory-groups

# Advisory Groups

The Advisory Councils at Fordham are made up of dedicated people—Fordham people. They are the kind of alumni and friends we recognize easily as our own for their commitment, care, and generosity.

Each of these advisory boards donates its time and resources to promote Fordham, whether to spur growth in the sciences and research, or to help mobilize alumni and parents to enrich the lives of our students and the University.