https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2023-womens-summit/2023-womens-summit-sessions

# 2023 Women's Summit Sessions

### Student Scholarship Speaker

### Meredith Leahy, FCRH '25

**Major: **Environmental Science

**Meredith Leahy, FCRH ’25**, is an environmental science major from Seattle. She is a member of the USG Sustainability Committee and Students for Environmental Action and Justice. She works with a team of students pushing Fordham to divest its endowment from fossil fuels. She also works with the Wildlife Conservation Society at the Bronx Zoo through the Framing Our Future Ambassador Program. After graduating, Leahy is interested in pursuing a career in conservation biology.

![Student, Professional Headshot](/media/home/departments-centers-and-offices/give/Headshot-2.jpeg)