https://www.fordham.edu/digital-campaign-b

# For Your Career

For doers, acheivers, and future leaders

# For Your Career

## For the Impact You’ll Make

At Fordham’s Gabelli School of Business, you’ll learn how to become a leader on the world stage by studying business with purpose in the global capital of the world.

See how our top-ranked business school will prepare you for your field and your future.

**30+**business majors, minors, and concentrations**14:1**student-to-faculty ratio**200+**student clubs for every interest**96%**of the Class of 2024 was employed or continuing their education within six months of graduation

![Student Managed Investment Fund at the Gabelli School.](/media/home/admin-use-only/brand-stories/gabellismifinside.jpg)


**The Fordham Internship Promise**

Our [internship promise](/academics/undergraduate-education/fordham-internship-promise/) means you’ll have the chance to land at least one internship, including research and experiential learning, by the time you graduate.

While many of our incredible students enjoyed a well-deserved summer break, others spent their time interning at some truly iconic organizations in New York City!